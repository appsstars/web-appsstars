<?php require_once 'layouts/header.php'; ?>
<div class="contenido">
	<section id="aplicaciones">
		<div class="row" id="cabecera">
			<div class="col-md-12">
				<img src="assets/img/banner_apps_moviles.png" alt="">
			</div>
		</div>
	</section>
</div>