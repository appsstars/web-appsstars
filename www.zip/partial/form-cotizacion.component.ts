import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng-form-cotizacion',
  templateUrl: 'form-cotizacion.component.html',
  styleUrls: ['./form-cotizacion.component.css']
})
export class FormCotizacionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
